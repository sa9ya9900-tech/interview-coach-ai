# Interview Coach AI — Android-friendly starter

This keeps the existing HTML interface and adds a small Node.js backend that calls the OpenAI Responses API.
The API key stays on the server, not in browser JavaScript.

## Run it on a phone using Replit (or another Node.js host)

1. Open https://replit.com in your Android browser and sign in.
2. Create a new Node.js app/project.
3. Upload or create these files preserving the structure:
   - `server.js`
   - `package.json`
   - `public/index.html`
4. Open the host's **Secrets / Environment Variables** tool and add:
   - Key: `OPENAI_API_KEY`
   - Value: your API key from https://platform.openai.com/api-keys
5. Optional: add `OPENAI_MODEL` with a model available to your API account. The default in this starter is `gpt-6-astra`.
6. Run the project with `npm start` (or the platform's Run button).
7. Open the provided web preview URL and test a short answer.

## Important security and cost notes

- Never paste your API key into `public/index.html`, a public GitHub repository, or a chat.
- API usage is billed separately from a ChatGPT subscription; check API billing and usage limits before testing.
- If the model named in `OPENAI_MODEL` is not available to your API account, change it to a model that is available in your account.
- The scores are AI-generated estimates, not an official hiring decision. Always keep your answers truthful.
- This starter does not store answers in a database. Hosting providers may have their own logs.
