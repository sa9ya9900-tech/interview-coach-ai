import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const port = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/evaluate", async (req, res) => {
  const { role, company, question, answer, language } = req.body || {};
  if (![role, question, answer].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Please provide your job role, interview question, and answer." });
  }
  if (answer.length > 12000) {
    return res.status(413).json({ error: "Please keep your answer under 12,000 characters." });
  }
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({
      error: "AI is not connected yet. Add your OPENAI_API_KEY in the hosting platform's Secrets or Environment Variables, then restart the app."
    });
  }

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const instructions = `You are a supportive but honest job-interview coach and English grammar tutor.
Evaluate only the candidate's answer to the supplied question. Consider the job role and company context when relevant.
Do not invent candidate experience, qualifications, achievements, or facts. The improved answer must preserve the candidate's meaning and must use placeholders like [add a real example] where details are missing.
Correct grammar, spelling, punctuation, and awkward phrasing. Explain each correction in simple language. Do not mark acceptable informal speech as wrong unless it harms a professional interview answer.
Return ONLY valid JSON, with exactly these fields:
{
 "overall_score": number,
 "grammar_score": number,
 "relevance_score": number,
 "clarity_score": number,
 "strengths": string[],
 "grammar_corrections": [{"original": string, "corrected": string, "explanation": string}],
 "improvements": string[],
 "improved_answer": string,
 "tip": string
}
All scores must be numbers from 1 to 10 and must be justified by the answer. If there are no clear grammar errors, return an empty grammar_corrections array. Be specific, kind, and educational. Use the requested feedback language for explanations, strengths, improvements, and tip when possible; keep corrected English sentences in English.`;
    const input = [
      `Feedback language: ${String(language || "English").slice(0, 40)}`,
      `Job role: ${role.trim().slice(0, 200)}`,
      `Company: ${(typeof company === "string" && company.trim()) ? company.trim().slice(0, 200) : "Not specified"}`,
      `Interview question: ${question.trim().slice(0, 1500)}`,
      `Candidate answer:\n${answer.trim()}`
    ].join("\n\n");

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-astra",
      instructions,
      input,
      max_output_tokens: 1800
    });

    let result;
    try {
      result = JSON.parse(response.output_text);
    } catch {
      console.error("AI returned non-JSON output.");
      return res.status(502).json({ error: "The AI response was not in the expected format. Please try again." });
    }

    const score = value => Math.max(1, Math.min(10, Math.round(Number(value) || 1)));
    result.overall_score = score(result.overall_score);
    result.grammar_score = score(result.grammar_score);
    result.relevance_score = score(result.relevance_score);
    result.clarity_score = score(result.clarity_score);
    result.strengths = Array.isArray(result.strengths) ? result.strengths.slice(0, 6) : [];
    result.grammar_corrections = Array.isArray(result.grammar_corrections) ? result.grammar_corrections.slice(0, 12) : [];
    result.improvements = Array.isArray(result.improvements) ? result.improvements.slice(0, 6) : [];
    result.improved_answer = String(result.improved_answer || "");
    result.tip = String(result.tip || "");
    return res.json(result);
  } catch (error) {
    console.error("Evaluation request failed:", error?.message || error);
    if (error?.status === 401) {
      return res.status(502).json({ error: "The API key was rejected. Check the OPENAI_API_KEY secret." });
    }
    if (error?.status === 429) {
      return res.status(429).json({ error: "The AI service is rate-limited or your API account needs billing/credits. Check your API usage and billing settings." });
    }
    return res.status(502).json({ error: "The AI service could not evaluate this answer. Please try again in a moment." });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Interview Coach AI is running on port ${port}`);
});
